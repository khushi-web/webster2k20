from os import name
from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Applicants(models.Model):
    applicant = models.OneToOneField(User,on_delete=models.CASCADE)
   # name = models.CharField(max_length=200, null=True)
    app_email=models.CharField(max_length=255, null=True)
    app_clg=models.CharField(max_length=255, null=True)
    dateregisteres= models.DateTimeField(auto_now_add=True, null=True)
    phone = models.PositiveIntegerField(null=True)
    STATUS = (
        ('Pending', 'Pending'),
        ('Denied','Denied'),
        ('Accept','Accept'),
    )
    status = models.CharField(max_length=200, null=True, choices=STATUS)
    def __str__(self):
        return str(self.applicant)

class College(models.Model):
    app_clg = models.OneToOneField(Applicants,on_delete=models.CASCADE, null=True)
    dateregisteres= models.DateTimeField(auto_now_add=True, null=True)
    STATUS = (
        ('Pending', 'Pending'),
        ('Denied','Denied'),
        ('Accept','Accept'),
    )
    status = models.CharField(max_length=200, null=True, choices=STATUS)
    def __str__(self):
        return str(self.college)

class Ambassador(models.Model):
    amb_name = models.OneToOneField(User,on_delete=models.CASCADE)
   # name = models.CharField(max_length=200, null=True)
    app_email=models.CharField(max_length=255, null=True)
    app_clg=models.CharField(max_length=255, null=True)
    dateregisteres= models.DateTimeField(auto_now_add=True, null=True)

