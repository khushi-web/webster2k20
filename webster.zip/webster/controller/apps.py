from django.apps import AppConfig


class ControllerConfig(AppConfig):
    name = 'controller'
