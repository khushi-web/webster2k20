from django.http import request
from django.http.response import JsonResponse
from django.shortcuts import render
from accounts.decorators import unauthenticated_user, allowed_users, admin_only
from user.models import Profile
from controller.models import Applicants
from controller.models import College
from controller.models import Ambassador
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Ambassador, Applicants, College
# Create your views here.
@login_required(login_url='login') # when user is not logged in 
@admin_only #only admin has right to this page. we can also add multiple users like staff etc.
def homepage(request):
    context={}
    return render(request,'controller/home.html', context)

def viewapplicants(request):
    item = Applicants.objects.all()
    context ={'item' : item}
    return render(request,'controller/viewapp.html',context)

def dashboard(request):
    
	Ambassador = Ambassador.objects.all()
	Applicants = Applicants.objects.all()

	total_app = Applicants.count()

	total_amb = Ambassador.count()
	accept = Applicants.filter(status='Accept').count()
	pending = Applicants.filter(status='Pending').count()
	cancel = Applicants.filter(status='Cancel').count()

	context = {'ambassador':ambassador, 'applicant':Applicants,
	'total_amb':total_amb,'accept':accept,
	'pending':pending ,'cancel':cancel}

	return render(request, 'controller/dashboard.html', context)

#@login_required(login_url='login')
#@allowed_users(allowed_roles=['admin'])	
#def confirmapplicant(request):
#	userid = request.POST["applicant"]
#	Collegename = request.POST["applicant"]
#	if CollegeAmbassador.objects.get(Collegename = Collegename):

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteRequest(request, pk):
	applicants = Applicants.objects.get(id=pk)
	if request.method == "POST":
		Applicants.delete()
		#return redirect('/')

	context = {'item':applicants}
	return render(request, 'controller/delete.html', context)

