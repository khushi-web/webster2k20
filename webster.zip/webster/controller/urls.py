from os import name
from django.urls import path,include
from . import views



urlpatterns = [
    path('',views.homepage,name="home"),
    path('viewapplicants',views.viewapplicants,name="viewapplicants"),
    path('dashboard',views.dashboard,name="dashboard"),
    path('delete_request/<str:pk>/', views.deleteRequest, name="delete_request"),
]