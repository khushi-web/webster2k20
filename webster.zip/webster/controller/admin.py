from django.contrib import admin
from .models import Ambassador, Applicants, College
# Register your models here.

class ApplicantsAdmin(admin.ModelAdmin):

    #fields = ['applicant','app_email','app_clg','dateregisteres','phone']

    #search_fields = ['applicant','app_clg','phone']

    list_filter = ['applicant','app_clg']

    list_display = ['applicant','app_clg','status']

    list_editable = ['status']


admin.site.register(Applicants,ApplicantsAdmin)
admin.site.register(College)
admin.site.register(Ambassador)

