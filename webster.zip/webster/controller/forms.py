from django.db.models import fields
from django.forms import ModelForm
from django import forms
from django.contrib.auth.models import Ambassador
class Ambassador(ModelForm):
    class Meta :
        model = Ambassador
        fields = '__all__'
